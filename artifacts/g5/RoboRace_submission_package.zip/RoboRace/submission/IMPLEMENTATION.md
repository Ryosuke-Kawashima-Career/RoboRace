# G4 / G4b implementation and reproduction

The G4 command freezes 40 held-out layouts (first ten per course from the existing test manifest), the three existing controllers and the decision rule before evaluation. BC and PPO each use training seed 0. This implements the roadmap's explicitly preliminary fallback, not the full three-training-seed experiment. No training or policy tuning is performed on these test results. The remaining 60 test layouts are unconsumed by this command.

## Reproduce

From the repository root in PowerShell:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements-3d.txt
.venv\Scripts\python.exe -m roborace.g4 compare
.venv\Scripts\python.exe -m roborace.g4 demo
.venv\Scripts\python.exe -m pytest -q
```

The comparison writes `artifacts/g4/frozen_manifest.json`, all episode records and trajectories, `episodes.jsonl`, `summary.json`, and `comparison.png`. Scenario bootstrap uses 5,000 paired resamples, seed 415; intervals represent scenario variation only. Source/config/checkpoint hashes resolve through per-episode artifacts and retained source snapshots. The 2D contract and split manifests are unchanged. A backend hook preserves the existing midpoint integrator and conservative collision response.

The demo writes `artifacts/g4b/scene.json`, backend/config/runtime/source records and one MP4, step log, final image and outcome per method. Its predesignated seed-41000 scene has three simultaneous starts, matching colored goals and two raised obstacles between separated driving lanes. This is an integration demonstration, not a difficult obstacle-avoidance reliability test. Test layouts do not guide this scene. Results are never pooled across 2D and 3D.

## 3D model and limitations

PyBullet DIRECT advances massive cylindrical chassis using a body-frame velocity servo, 0.01-second physics steps and 0.1-second control steps. Gravity is disabled to constrain planar motion. Visible wheels and heading markers are decorative; wheel torque, tire friction, suspension and motor dynamics are not modeled. Actual Bullet poses feed the unchanged 44-value observation encoding. Analytic planar range rays use the matching cylinder/box footprints and measured peer poses; these are not Bullet ray casts. Contacts come from Bullet, and contact poses are retained. No classical avoidance or policy fallback is injected into learned actions. Existing checkpoint-loaded arrival stopping is disclosed.

The scene has distinct chassis, wheel markers, floor, walls, raised obstacles, start/goal discs and a fixed overview. Overlays identify controllers, robot colors, simulation time, finishes and contacts. Each control step produces a frame at 10 fps (1x). Robots finishing within 0.1 seconds share rank; IDs order display. All attempts are retained. Robot/scene shapes are generated in code; no external visual assets are used. PyBullet uses its upstream zlib license; package licenses remain in installed distributions.

These raw recordings are not the edited G5 1–3 minute submission video. G5 packaging and portal submission remain separate work. Full multi-seed G4, broader 3D transfer validation and wheel-driven physics remain limitations. Path efficiency and minimum-clearance analysis are not implemented in this preliminary comparison; path length is retained. Training curves/costs remain available in the original G2/G3 artifacts.

## Measured G4 results

| Controller | Team success | Collisions | Timeouts | Capped seconds | Successful makespan |
|---|---:|---:|---:|---:|---:|
| classical | 12/40 | 0 | 28 | 45.195 | 10.650 |
| bc | 10/40 | 30 | 0 | 48.260 | 13.040 |
| ppo | 20/40 | 20 | 0 | 38.212 | 16.425 |

PPO is the practical AI-demo choice: highest measured success and lowest capped completion. All methods fail every slalom and bottleneck layout. PPO succeeds on ten open and ten crossing layouts; BC on ten open layouts; classical on ten open and two crossing layouts. The 80% target is not met.

Paired 95% scenario-bootstrap intervals for success differences:

- classical minus bc: [0.000, 0.125].
- classical minus ppo: [-0.325, -0.075].
- bc minus ppo: [-0.400, -0.125].

One training seed does not measure training variation. Inference timings shared the CPU with native compilation and are descriptive only. Source snapshots vary because 3D-only code was added concurrently; controller weights and 2D dynamics did not change. All 28 tests pass, including 3D motion, yaw, deterministic reset, known sensor distances/masks, peer/static contacts and arrival stopping.

BC used 4,057 training samples, 50 epochs (selected epoch 40), 24.16 seconds fitting plus 126.31 seconds expert collection. PPO used 32,768 world steps, 91,215 policy-agent transitions, 392.12 seconds training (selected update 96). These are retained pilot costs, not equal budgets or a complete historical tuning audit. No new training was performed.

## Measured 3D transfer results

All three methods completed the single predesignated integration scene, three robots each, without contacts or timeouts.

| Method | 2D makespan | 3D makespan | 3D finish times | Ranks |
|---|---:|---:|---|---|
| classical | 10.2s | 10.2s | [10.2, 10.2, 10.2] | [1, 1, 1] |
| bc | 10.4s | 10.4s | [10.2, 10.4, 10.4] | [1, 2, 2] |
| ppo | 15.9s | 15.9s | [15.7, 15.8, 15.9] | [1, 1, 2] |

The 2D reference was measured on the same integration-only scene and is retained under `artifacts/g4b/planar_reference`; it is separate from held-out metrics. No transfer retuning was required. A pre-recording command failed while package metadata was still being installed, before an episode started; it was retried after installation completed. Three physics race attempts were then recorded, all successful.

`artifacts/g4b/comparison.mp4` shows all three races synchronized at 1x with explicit terminal-frame holds. Every raw MP4 frame was decoded while composing it; counts are retained in `video_verification.json`. Final PPO camera output was visually inspected: robots, raised obstacles, start/goal discs and readable status overlay are visible. The raw clips are about 10.3, 10.5 and 16.0 seconds. This verifies playback/encoding and selected visual frames, not an end-to-end human review of a final submission edit.

Status: G4 preliminary single-seed comparison delivered; full multi-seed G4 remains incomplete. G4b physics integration and a successful learned-controlled 3D race delivered; the wider transfer-validation suite and challenging obstacle-avoidance reliability remain incomplete. G5 final 1–3 minute presentation/package remains planned.


# G5 local submission implementation

Implemented October 25, 2026. Status: local media and reproducible-package preparation implemented; external publication/submission pending. Full G4 multi-seed comparison and broader G4b transfer validation remain incomplete and are disclosed in the report/video. This does not claim the entire roadmap or course submission is complete.

## Delivered artifacts

- `artifacts/g5/RoboRace_submission.mp4`: exactly 120.0 seconds, H.264, 1280x720, 10 fps, captioned with no audio. The uninterrupted PPO race occupies 30-46 s; all 160 raw frames appear at 1x. The synchronized comparison occupies 56-72 s. Still frames, independent runs and terminal holds are labeled. Measured test results and failures are explained.
- `artifacts/g5/説明資料_PAI最終課題_83792.pdf`: four-page report covering purpose, original contributions, dynamics/AI methods, budgets, results, uncertainty, limitations, evidence and reproduction. Uses permitted account ID 83792 in the required filename; account name is not published.
- `artifacts/g5/RoboRace_submission_package.zip`: allowlisted source/configs/scripts/tests, scenario manifests, checkpoints, dataset/training evidence, complete G4 episode evidence, raw 3D recordings/logs, final media and SHA-256 manifest. Environments, private planning/course documents and Git history are excluded.
- `artifacts/g5/release/RoboRace/submission/UPLOAD_METADATA.md`: prepared YouTube title `PAI最終課題_83792`, description, proposed settings and explicit pending external steps.
- `artifacts/g5/package_manifest.json`: package hash/size and exclusion record.

## Implementation

`scripts/build_g5_video.py` builds the eight-section film from retained simulator recordings and raw-result chart. It decodes the complete exported movie, checks the expected 1,200 frames and writes timeline/encoding checks. `scripts/build_g5_pdf.py` generates the report with ReportLab using the bundled authoring runtime. `scripts/package_g5.py` stages an allowlisted release, copies dependency license files, creates per-file SHA-256 hashes and tests the ZIP. `scripts/verify_g5.py` verifies file integrity, reconciles all 120 method-episode records with reported summaries and verifies both learned 3D checkpoint hashes.

`requirements-release.txt` defines direct CPU runtime/test dependencies. The isolated Windows/Python 3.13 environment generates `requirements-release-lock.txt` for exact transitive versions. PyBullet reused the locally built cp313 Windows wheel; a new machine without a compatible wheel may require Windows C++ build tools. No full training rerun or new held-out tuning is claimed.

## Media verification

All 1,200 film frames decode successfully. The exported film was reviewed chronologically using one-second contact sheets spanning 0-119 s, plus section/boundary samples. Labels, camera sequence, result tables and limitations are present; moving footage is 1x. These automated-agent checks are not a claim of human audiovisual review. No audio track is present. Every PDF page was rendered with Poppler and visually inspected. An initial orphaned paragraph was corrected; the final report is four pages. Local screenshot/render QA files remain outside the public source archive.

## Publication boundary and remaining items

No repository publication, YouTube upload, OmniCampus action or external messaging was performed. The package contains reviewable files and proposed metadata; public URLs and portal confirmation cannot be verified locally. Current portal instructions/deadline still require account-based verification. Keep the eventual video available until grading is complete. The user supplied account name and ID; only the permitted ID is used in submission naming.

No secret-bearing configuration, user profile, virtual environment, private course PDF or private planning directory is included in the allowlisted release. Machine paths and account-name patterns are scanned before delivery. Checkpoint files are retained with their recorded hashes. Third-party authorship/license notices are preserved and do not imply original authorship of dependencies.

## Isolated runtime verification

A new `.venv-g5` without system-site-packages installed the pinned direct runtime and transitive dependencies successfully. `pip check` reports no broken requirements. All 28 tests passed in 8.78 seconds. The PPO smoke run loaded the included checkpoint, completed the actual 3D integration race with all three robots, no contact and a 15.9-second makespan, and captured a 960x720 frame. All 120 comparison records and both learned checkpoint hashes reconcile. Exact transitive versions are in `requirements-release-lock.txt`; `artifacts/g5/clean_environment.json` retains the verification record. This validates a clean dependency environment on the same Windows host, not a second operating system or an uncached PyBullet build.
