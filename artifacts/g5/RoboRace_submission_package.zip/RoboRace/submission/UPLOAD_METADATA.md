# Prepared upload metadata (not uploaded)

YouTube title: PAI最終課題_83792
PDF filename: 説明資料_PAI最終課題_83792.pdf

Proposed description: Three robots race in a 3D PyBullet world under a saved PPO checkpoint. This captioned 120-second film includes continuous 1x footage, a three-method comparison, preliminary 40-layout held-out results and limitations. BC/PPO each have one training seed. The 3D integration scene is easy and uses ideal velocity-servo bodies with decorative wheels. PPO success is 20/40, below the 80% target. Raw evidence and reproduction code accompany the package. All moving footage is 1x; cuts, stills and finished-panel holds are labeled.

External steps still unperformed:
- Publish the repository and verify signed-out source/checkpoint access.
- Upload the final MP4; choose at least unlisted visibility.
- Set not made for kids, no age restriction and instant premiere disabled.
- Verify signed-out playback; keep video available through grading.
- Check current course portal instructions and deadline.
- Submit PDF, public repository URL and YouTube URL to OmniCampus; retain private confirmation.

Public repository URL: pending publication.
YouTube URL: pending upload.
OmniCampus confirmation: pending submission.
Account name is deliberately omitted; permitted account ID 83792 is used.
