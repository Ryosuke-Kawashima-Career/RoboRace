"""G1 commands: python -m roborace.cli demo / evaluate / scenarios."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import time
import numpy as np
from .controller import Classical
from .env import World
from .render import frame
from .scenarios import COURSES, build_manifests

ROOT = Path(__file__).resolve().parents[1]


def source_hash():
    digest = hashlib.sha256()
    for path in sorted((ROOT / 'roborace').glob('*.py')):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def rollout(cfg, seed, course, output, recording=False, scene=None):
    output.mkdir(parents=True, exist_ok=True)
    world, policy = World(cfg), Classical()
    observation = world.reset(seed, course, scene)
    policy.reset(seed)
    frames = [frame(world)] if recording else []
    latency = []
    states, actions_log = [world.state.tolist()], []
    start = time.perf_counter()
    while not (world.terminated or world.truncated):
        t = time.perf_counter()
        actions = policy.act(observation)
        latency.append(time.perf_counter() - t)
        observation, _, _, _, _ = world.step(actions)
        states.append(world.state.tolist())
        actions_log.append(actions.tolist())
        if recording and (world.steps % 2 == 0 or world.terminated or world.truncated):
            frames.append(frame(world))
    result = world.summary()
    result.update({'method': 'classical', 'seed': seed, 'course': course,
                   'wall_time_s': time.perf_counter() - start,
                   'controller_mean_ms': float(np.mean(latency) * 1000), 'controller_p95_ms': float(np.percentile(latency, 95) * 1000),
                   'source_sha256': source_hash(), 'scene_sha256': hashlib.sha256(json.dumps(world.scene, sort_keys=True).encode()).hexdigest(),
                   'config_sha256': hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).hexdigest(),
                   'trajectory_sha256': hashlib.sha256(np.asarray(states, dtype='<f8').tobytes()).hexdigest(),
                   'python': platform.python_version(), 'numpy': np.__version__})
    (output / 'episode.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    (output / 'trajectory.json').write_text(json.dumps({'scene': world.scene, 'states': states, 'actions': actions_log}) + '\n', encoding='utf-8')
    if recording:
        # The last frame's duration represents any final odd control step.
        durations = [200] * len(frames)
        if world.steps % 2:
            durations[-2] = 100
        durations[-1] = 200
        frames[0].save(output / 'rollout.gif', save_all=True, append_images=frames[1:], duration=durations, loop=0)
        frames[-1].save(output / 'final.png')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['demo', 'evaluate', 'scenarios'])
    parser.add_argument('--config', type=Path, default=ROOT / 'configs/g0_contract.json')
    parser.add_argument('--seed', type=int, default=20000)
    parser.add_argument('--course', choices=COURSES, default='open')
    parser.add_argument('--output', type=Path, default=ROOT / 'artifacts/g1')
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text(encoding='utf-8'))
    if args.command == 'scenarios':
        summary = build_manifests(ROOT / 'scenarios', cfg)
        args.output.mkdir(parents=True, exist_ok=True)
        (args.output / 'scenario_validation.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(summary, indent=2))
    elif args.command == 'demo':
        print(json.dumps(rollout(cfg, args.seed, args.course, args.output, True), indent=2))
    else:
        # G1 evaluates only validation layouts, never the held-out test manifest.
        records = json.loads((ROOT / 'scenarios/validation/manifest.json').read_text())
        results = [rollout(cfg, s['seed'], s['course'], args.output / str(s['seed']), scene=s) for s in records[:8]]
        summary = {'split': 'validation', 'episodes': len(results),
                   'successes': sum(r['team_success'] for r in results),
                   'collision_episodes': sum(r['collision'] is not None for r in results),
                   'timeouts': sum(r['timeout'] for r in results),
                   'note': 'G1 integration sample, not frozen held-out method comparison', 'results': results}
        (args.output / 'validation_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({k: v for k, v in summary.items() if k != 'results'}, indent=2))


if __name__ == '__main__':
    main()
